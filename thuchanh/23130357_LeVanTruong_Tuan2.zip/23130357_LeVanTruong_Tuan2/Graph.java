package thuchanh;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;
import java.util.Stack;

public abstract class Graph {
	protected int numVexs;
	protected int[][] adjMatrix;
	protected  String path="src/thuchanh/test1.txt";
	protected boolean[] track;
	ArrayList<Integer> dfs = new ArrayList<Integer>(); 
	ArrayList<Integer> bfs = new ArrayList<Integer>(); 
	Queue<Integer> queue = new LinkedList<Integer>();
	Stack<Integer> stack = new Stack<Integer>();
	public Graph(int numVexs, int[][] adjMatrix) {
		super();
		this.numVexs = numVexs;
		this.adjMatrix = adjMatrix;
	}
	public Graph() {
		// TODO Auto-generated constructor stub
	}
	//cau 1
	public boolean loadGraph(String pathFile) throws IOException{
		File input = new File(pathFile);
		BufferedReader reader = new BufferedReader(new FileReader(input));
		String lineFirst = reader.readLine();
		this.numVexs=Integer.parseInt(lineFirst);
		this.adjMatrix=new int[numVexs][numVexs];
		String lines="";
		int indexLine=0;
		while((lines=reader.readLine())!=null) {
			String[] dt = lines.split(" ");
			for(int i =0;i<numVexs;i++) {
				this.adjMatrix[indexLine][i]=Integer.parseInt(dt[i]);
			}
			indexLine++;
		}
		reader.close();
		return true;
	}
	public static void printMatrix(int[][] arr) {
		for (int i = 0; i < arr.length; i++) {
			for (int j = 0; j < arr[i].length; j++) {
				System.out.print(arr[i][j]+" ");
			}
			System.out.println();
		}
	}
	//cau 3
	public abstract boolean checkValid(int[][] array);
	//cau 5
	public abstract void addEdge(int[][] array, int v1, int v2);
	//cau 6
	public abstract void removeEdge(int[][] array, int v1, int v2);
	//cau 7
	public abstract int deg(int v);
	//cau 8
	public abstract int sumDeg();
	//cau 9
	public abstract int sumVertexs();
	//cau 10
	public abstract int sumEdges();
	// cau 11
	public abstract boolean checkConnection();
	
	public void reset() {
		for (int i = 0; i < track.length; i++) {
			track[i]=false;
		}
	}
	//trả về danh sách các cạnh kề
	public ArrayList<Integer> danhSachKe(int[][] arr, int v){
		HashMap<Integer, ArrayList<Integer>> danhSach = new HashMap<Integer, ArrayList<Integer>>();
		for (int i = 0; i < arr.length; i++) {
			ArrayList<Integer> canhKe = new ArrayList<Integer>();
			for (int j = 0; j < arr[i].length; j++) {
				if(arr[i][j]==1) {
					canhKe.add(j+1);
					danhSach.put(i+1, canhKe);
				}
				//kiem tra canh song song
				if(arr[i][j]==2) {
					canhKe.add(j+1);
					canhKe.add(j+1);
					danhSach.put(i+1, canhKe);
				}
			}
		}
		return danhSach.get(v);
	}
	//cau 12
	// cau 13
	public void BFSGraph(int v) {
		queue.add(v);
		while(!queue.isEmpty()) {
			int dinhDangXet = queue.poll();
			if(dfs.contains(dinhDangXet)==false) {
				dfs.add(dinhDangXet);
				System.out.println("đã xét: " + dinhDangXet);
			}
			ArrayList<Integer> danhSachKe = danhSachKe(adjMatrix, dinhDangXet);
			System.out.println("danh sách đỉnh kề: "+danhSachKe);
			for (int i = 0; i < danhSachKe.size(); i++) {
				if(!queue.contains(danhSachKe.get(i)) && !dfs.contains(danhSachKe.get(i))) {
					queue.add(danhSachKe.get(i));
				}
			}
			System.out.println("queue" + queue);
			System.out.println("bfs" +dfs);
		}
	}
	// cau 14
		public void DFSGraph(int v) {
			stack.add(v);
			while(!stack.isEmpty()) {
				int dinhDangXet = stack.pop();
				if(bfs.contains(dinhDangXet)==false) {
					bfs.add(dinhDangXet);
					System.out.println("đã xét: " + dinhDangXet);
				}
				ArrayList<Integer> danhSachKe = danhSachKe(adjMatrix, dinhDangXet);
				System.out.println("danh sách đỉnh kề: "+danhSachKe);
				for (int i = 0; i < danhSachKe.size(); i++) {
					if(!stack.contains(danhSachKe.get(i)) && !bfs.contains(danhSachKe.get(i))) {
						stack.add(danhSachKe.get(i));
					}
				}
				System.out.println("stack" + stack);
				System.out.println("dfs" +bfs);
				
			}	
	}
	// cau 15
		public boolean isConnected() {
	        int n = this.adjMatrix.length;
	        boolean[] visited = new boolean[n];
	        Queue<Integer> queue = new LinkedList<>();
	        queue.add(0);
	        visited[0] = true;
	        int count = 1; 

	        while (!queue.isEmpty()) {
	            int dinhDangXet = queue.poll();
	            for (int i = 0; i < n; i++) {
	                if (this.adjMatrix[dinhDangXet][i] == 1 && !visited[i]) { 
	                    queue.add(i);
	                    visited[i] = true;
	                    count++; 
	                }
	            }
	        }
	        return count == n;
	    }
	// cau 16
	// cau 17
		public boolean checkBipartiteGraph(int start) {
			 int n = this.adjMatrix.length;
			 int[] color = new int[n]; 
			 Arrays.fill(color, 0); 
			 Queue<Integer> queue = new LinkedList<>();
			 queue.add(start);
			 color[start] = 1; 
			 while (!queue.isEmpty()) {
				 int dinhDangXet = queue.poll();
			     for (int i = 0; i < n; i++) {
			    	 if (this.adjMatrix[dinhDangXet][i] == 1) {
			         if (color[i] == 0) { 
			        	 color[i] = -color[dinhDangXet];
			             queue.add(i);
			         }else if (color[i] == color[dinhDangXet]) {
			        	 return false;
			         }
			         }
			     }
			 }
			return true;
		}

 }
