package thuchanh;
import java.io.IOException;

public class Main {
	public static void main(String[] args) throws IOException {
		Graph unGraph = new UnGraph();
		if(unGraph.loadGraph(unGraph.path)==true) {
			unGraph.printMatrix(unGraph.adjMatrix);
		}
//		System.out.println(unGraph.checkValid(unGraph.adjMatrix));
////		unGraph.addEdge(unGraph.adjMatrix, 0, 3);
//		System.out.println("them canh");
//		unGraph.printMatrix(unGraph.adjMatrix);
////		unGraph.removeEdge(unGraph.adjMatrix, 3, 2);
////		unGraph.removeEdge(unGraph.adjMatrix, 0, 3);
//		System.out.println("xoa canh");
//		unGraph.printMatrix(unGraph.adjMatrix);
////		System.out.println("tổng bậc của đỉnh: "+ ++v +" là "+ unGraph.deg(2));
//		System.out.println(unGraph.sumEdges());
		System.out.println("Kiem tra do thi lien thong: "+unGraph.checkConnection());
//		System.out.println(unGraph.danhSachKe(unGraph.adjMatrix, v));
		int v = 2;
		unGraph.BFSGraph(v);
		System.out.println("///////////////////////////////");
		unGraph.DFSGraph(v);
		System.out.println(unGraph.checkBipartiteGraph(1));
		System.out.println(unGraph.isConnected());
	}
}
