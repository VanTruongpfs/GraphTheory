package thuchanh;

public class UnGraph extends Graph{

	public UnGraph() {
		super();
	}
	@Override
	public boolean checkValid(int[][] array) {
		for (int i = 0; i < array.length; i++) {
			for (int j = 0; j < array.length; j++) {
				if(array[i][j]!=array[j][i]) {
					return false;
				}
			}
		}
		return true;
	}
	public void addEdge(int[][] matrix, int v1, int v2) {
		if(v1<0||v1>numVexs||v2<0||v2>numVexs|| v1==v2) {
			System.out.println("Sai");
		}else {
			matrix[v1][v2] = matrix[v2][v1]=1;
		}
	}
	@Override
	public void removeEdge(int[][] matrix, int v1, int v2) {
		if(v1<0||v1>numVexs||v2<0||v2>numVexs) {
			System.out.println("Sai");
		}else {
			matrix[v1][v2] = matrix[v2][v1]=0;
		}
		
	}
	@Override
	public int deg(int v) {
		int sum = 0;
		if(v>=0 && v<this.numVexs) {
			for (int i = 0; i < this.numVexs; i++) {
				sum+=this.adjMatrix[v][i];
			}
		}
		return sum;
	}
	@Override
	public int sumVertexs() {
		return this.numVexs;
	}
	@Override
	public int sumEdges() {
		int sumLevelOfAllVertexs = 0;
		for (int i = 0; i < this.adjMatrix.length; i++) {
			if(this.adjMatrix[i][i]==1) {
				sumLevelOfAllVertexs+=1;
			}
			for (int j = 0; j < this.adjMatrix[i].length; j++) {
				sumLevelOfAllVertexs+=this.adjMatrix[i][j];
			}
		}
		int result = sumLevelOfAllVertexs/2;
		return result;
	}
	@Override
	public int sumDeg() {
		int result = 0;
		for (int i = 0; i < adjMatrix.length; i++) {
			for (int j = 0; j < adjMatrix[i].length; j++) {
				result+=adjMatrix[i][j];
			}
		}
		return result;
	}
	public boolean checkConnection() {
		int count = 0;
		int v=0;
		track = new boolean[this.numVexs];
		track[v]=true;
		count++;
		for (int i = 0; i < adjMatrix.length; i++) {
			if(track[i]==true) {
				for (int j = 0; j < adjMatrix[i].length; j++) {
					if(adjMatrix[i][j]!=0 && track[j]==false) {
						track[j]=true;
						count++;
						if(count==numVexs) {
							return true;
						}
					}
				}
			}
		}
		return false;
	}
	
	
}
