package thuchanh;

public class Edge implements Comparable<Edge>{
	int srs, dest, weight;
	@Override
	public int compareTo(Edge o) {
		return this.weight - o.weight;
	}
	

}
